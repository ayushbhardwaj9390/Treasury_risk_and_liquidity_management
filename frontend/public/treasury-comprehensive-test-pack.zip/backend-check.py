"""Create and exercise an isolated fictional database. Never use production credentials."""
import csv
import json
import os
from pathlib import Path
import sys
from datetime import date, datetime, UTC
from decimal import Decimal

HERE = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE.parents[1] / 'work/global-treasury-ai-production-phase1-v2'
DATABASE = HERE / 'fictional-test.db'
if DATABASE.exists():
    raise SystemExit('fictional-test.db already exists; use a new sample folder for a fresh run.')
os.environ['DATABASE_URL'] = 'sqlite:///' + DATABASE.as_posix()
os.environ['ENVIRONMENT'] = 'development'
os.environ['AUTH_MODE'] = 'demo_header'
sys.path.insert(0, str(ROOT / 'backend'))
os.chdir(ROOT / 'backend')
from fastapi.testclient import TestClient
from sqlalchemy import select, delete
from app.main import app
from app.core.db import SessionLocal, Base, engine
from app.models import LegalEntity, CashFlow, FXRate

assumptions = json.loads((HERE / 'assumptions.json').read_text(encoding='utf-8'))
flows = list(csv.DictReader((HERE / 'treasury-comprehensive.csv').open(encoding='utf-8', newline='')))
catalog = json.loads((ROOT / 'frontend/lib/endpoints.json').read_text(encoding='utf-8'))
results, snapshots = [], {}
with TestClient(app, raise_server_exceptions=False) as client:
    with SessionLocal() as db:
        entities = db.scalars(select(LegalEntity)).all()
        country_names={'IN':'India','US':'USA','DE':'Germany','SG':'Singapore','GB':'UK','JP':'Japan'}
        for entity in entities:
            entity.name='Fictional Harbor '+country_names[entity.country_code]
        lookup={e.name:e.id for e in entities}
        db.execute(delete(CashFlow))
        for index,f in enumerate(flows):
            db.add(CashFlow(entity_id=lookup[f['entity']],flow_type='RECEIVABLE' if f['direction']=='INFLOW' else 'PAYABLE',counterparty=('Forecast Demo Fictional ' if index == 0 else 'Fictional ')+f['category']+' '+f['id'],currency=f['currency'],amount=Decimal(f['amount']),due_date=date.fromisoformat(f['date']),probability=Decimal(f['probability']),source_reference=f['id']))
        for c,rate in assumptions['rates'].items():
            if c not in {'EUR','GBP','INR','JPY','SGD'}:
                db.add(FXRate(base_currency=c,quote_currency='USD',rate=Decimal(rate),source='FICTIONAL_TEST_ASSUMPTION'))
        db.commit()
    for name,item in catalog.items():
        response=client.get(item['path'])
        results.append({'component':item['label'],'path':item['path'],'status':response.status_code,'expected':200})
        snapshots[name]=response.json()
    for path,expected in [('/health',200),('/health/ready',200),('/health/production',503),('/api/v1/production/releases/1',401)]:
        response=client.get(path)
        results.append({'component':path,'path':path,'status':response.status_code,'expected':expected})
        snapshots[path]=response.json()
    output=HERE / 'backend-tables'
    output.mkdir(exist_ok=True)
    tables={}
    with engine.connect() as conn:
        for table in Base.metadata.sorted_tables:
            records=[dict(r) for r in conn.execute(select(table)).mappings()]
            tables[table.name]={'records':len(records),'columns':[c.name for c in table.columns]}
            with (output / (table.name+'.csv')).open('w',encoding='utf-8',newline='') as target:
                writer=csv.DictWriter(target,fieldnames=tables[table.name]['columns'])
                writer.writeheader();writer.writerows(records)
    (HERE/'backend-data.json').write_text(json.dumps({'kind':'FICTIONAL_TEST_DATA_ONLY','tables':tables,'note':'CSV tables retain the development seed bank labels and simulated control evidence. These are not real bank records, certifications or approvals.'},indent=2)+'\n',encoding='utf-8')
    (HERE/'component-results.json').write_text(json.dumps({'kind':'FICTIONAL_TEST_EVIDENCE','checks':len(results),'results':results,'failures':[r for r in results if r['status']!=r['expected']]},indent=2)+'\n',encoding='utf-8')
    (HERE/'component-snapshots.json').write_text(json.dumps(snapshots,indent=2,default=str)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(results),'failed':[r for r in results if r['status']!=r['expected']],'populated_tables':sum(bool(t['records']) for t in tables.values()),'rows':sum(t['records'] for t in tables.values())}))
sys.exit(any(r['status']!=r['expected'] for r in results))
