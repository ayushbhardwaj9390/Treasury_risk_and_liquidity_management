"""Exercise draft storage and synthetic governance; leave live gates blocked."""
import csv, hashlib, json, os, sys
from pathlib import Path
from datetime import UTC, datetime, timedelta
HERE=Path(__file__).resolve().parent
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parents[1]/'work/global-treasury-ai-production-phase1-v2'
os.environ.update(DATABASE_URL='sqlite:///'+(HERE/'fictional-test.db').as_posix(),ENVIRONMENT='development',AUTH_MODE='demo_header')
sys.path.insert(0,str(ROOT/'backend'));os.chdir(ROOT/'backend')
from fastapi.testclient import TestClient
from sqlalchemy import select
from app.main import app
from app.core.db import Base, engine, SessionLocal
from app.models import CashFlow
from sqlalchemy import delete
# Reset only this runner's draft fixtures in the dedicated fictional database.
with engine.begin() as conn:
    for table in reversed(Base.metadata.sorted_tables):
        if table.name.startswith('production_') or table.name in {'company_profiles','company_planning_drafts','company_preferences','scheduled_updates','audit_logs'}:
            conn.execute(delete(table))
with SessionLocal() as db:
    first=db.scalar(select(CashFlow).order_by(CashFlow.id).limit(1))
    if not first.counterparty.startswith('Forecast Demo'):
        first.counterparty='Forecast Demo '+first.counterparty
    db.commit()
client=TestClient(app,raise_server_exceptions=False) # Existing database: deliberately do not reseed.
results=[];requests=[]
def call(method,path,payload=None,actor='treasurer1',expected=200):
    response=client.request(method,path,json=payload,headers={'X-Treasury-User':actor})
    results.append({'method':method,'path':path,'actor':actor,'status':response.status_code,'expected':expected,'response':response.json()})
    if payload is not None: requests.append({'method':method,'path':path,'actor':actor,'payload':payload,'expected':expected})
    assert response.status_code==expected,(path,response.status_code,response.text)
    return response.json()
a=json.loads((HERE/'assumptions.json').read_text(encoding='utf-8'))
flows=list(csv.DictReader((HERE/'treasury-comprehensive.csv').open(encoding='utf-8',newline='')))
profile={'company_name':'Fictional Harbor Energy Group','industry':'ENERGY','country_code':'US','expected_version':0}
call('POST','/api/v1/company/profile',profile,actor='analyst1',expected=403)
call('POST','/api/v1/company/profile',profile)
call('GET','/api/v1/company/setup')
call('PUT','/api/v1/company-preferences',{'countries':['IN','US','DE','SG','GB','JP'],'currencies':['USD',*a['rates']],'minimum_cash_usd':a['buffer'],'reviewer_roles':['TREASURY_MANAGER','GROUP_TREASURER','RISK_MANAGER','AUDITOR'],'expected_version':0})
call('PUT','/api/v1/company/planning-draft',{'flows':flows,'assumptions':{k:v for k,v in a.items() if k not in {'kind','company'}},'expected_version':0})
call('GET','/api/v1/company/planning-draft')
schedule=call('GET','/api/v1/scheduled-updates')
assert schedule['worker_status']=='BLOCKED'
for connector in schedule['schedules']:
    call('PUT','/api/v1/scheduled-updates',{'connector_id':connector['connector_id'],'interval_minutes':60,'stale_after_minutes':120,'enabled':False,'expected_version':0})
digest=hashlib.sha256((HERE/'treasury-comprehensive.xlsx').read_bytes()).hexdigest()
previous=hashlib.sha256((HERE/'treasury-comprehensive.csv').read_bytes()).hexdigest()
release=call('POST','/api/v1/production/releases',{'name':'FICTIONAL DATA WORKFLOW TEST ONLY','artifact_sha256':digest,'previous_artifact_sha256':previous})
rid=release['id'];base=f'/api/v1/production/releases/{rid}'
today=datetime.now(UTC)
call('POST',base+'/evidence',{'gate':'MODEL_VALIDATION','kind':'SYNTHETIC','result':'PASS','document_sha256':digest,'reference':'fixture://fictional-data-check-not-a-certification','scope':'Fictional test only','expires_at':(today+timedelta(days=30)).isoformat(),'details':{'model_version':'dummy-fixture-v1','developer':'fictional-developer','benchmark_sha256':digest,'limitations':'Synthetic data only. No real independent validation or certification.'}},actor='risk1')
for day in range(12):
    for metric in ['CASH','FORECAST','FX','LIQUIDITY','PAYMENTS','RISK']:
        call('POST',base+'/observations',{'day':(today-timedelta(days=day)).date().isoformat(),'metric':metric,'scope':'Fictional Harbor Group','kind':'SYNTHETIC','incumbent':'1000000','platform':'1000000','document_sha256':digest},actor='analyst1')
call('POST',base+'/transitions',{'action':'GO_LIVE','reason':'Negative test: synthetic evidence must not permit live use'},expected=403)
gate=call('GET',base)
assert gate['state']=='DRAFT'
call('GET',base+'/events')
call('POST','/api/v1/production/model-benchmark',{'actual':[100,120,90,110],'predicted':[101,118,92,109],'challenger':[105,115,95,105]},actor='risk1')
(HERE/'workflow-evidence.json').write_text(json.dumps({'kind':'FICTIONAL_TEST_EVIDENCE','checks':len(results),'results':results},indent=2,default=str)+'\n',encoding='utf-8')
(HERE/'backend-request-fixtures.json').write_text(json.dumps({'kind':'SYNTHETIC_REQUEST_EXAMPLES_ONLY','requests':requests},indent=2)+'\n',encoding='utf-8')
tables={}
with engine.connect() as conn:
    for table in Base.metadata.sorted_tables:
        records=[dict(r) for r in conn.execute(select(table)).mappings()]
        tables[table.name]={'records':len(records),'columns':[c.name for c in table.columns]}
        with (HERE/'backend-tables'/(table.name+'.csv')).open('w',encoding='utf-8',newline='') as target:
            writer=csv.DictWriter(target,fieldnames=tables[table.name]['columns']);writer.writeheader();writer.writerows(records)
(HERE/'backend-data.json').write_text(json.dumps({'kind':'FICTIONAL_TEST_DATA_ONLY','tables':tables,'note':'Development seed bank labels, controls and synthetic observations are fictional fixtures. Empty tables represent unexercised workflows; no real certifications or approvals supplied.'},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'workflow_checks':len(results),'rows':sum(t['records'] for t in tables.values()),'populated_tables':sum(bool(t['records']) for t in tables.values()),'production_state':gate['state']}))
