"""Compare every uploaded weekly balance to independent decimal arithmetic."""
import csv, json
from datetime import date, timedelta
from decimal import Decimal, localcontext, ROUND_HALF_UP
from pathlib import Path
here=Path(__file__).resolve().parent
rows=list(csv.DictReader((here/'treasury-comprehensive.csv').open(encoding='utf-8',newline='')))
base=json.loads((here/'assumptions.json').read_text(encoding='utf-8'))
expected=json.loads((here/'expected-planning-results.json').read_text(encoding='utf-8'))['scenarios']
changes={'base':{},'lateCustomers':{'delay':21},'costIncrease':{'costs':25},'lowerSales':{'receipts':-25},'oilIncrease':{'oil':20},'currencyShock':{'fx':15},'combined':{'delay':21,'costs':25,'receipts':-25,'oil':20,'fx':15}}
checks=0
with localcontext() as context:
    context.prec=50
    money=lambda value:format(value.quantize(Decimal('.01'),rounding=ROUND_HALF_UP),'.2f')
    for name,change in changes.items():
        a=base|change;start=date.fromisoformat(a['start']);end=start+timedelta(weeks=a['weeks'])
        buckets=[[Decimal(0),Decimal(0)] for _ in range(a['weeks'])]
        overdue=beyond=0
        for row in rows:
            original=date.fromisoformat(row['date']);inflow=row['direction']=='INFLOW'
            amount=Decimal(row['amount'])*Decimal('1' if row['currency']=='USD' else a['rates'][row['currency']])
            if row['currency']!='USD':amount*=1+Decimal(a['fx'])/100
            if row['category'] in {'CRUDE_PURCHASE','PRODUCT_SALE'}:amount*=1+Decimal(a['oil'])/100
            amount*=Decimal(row['probability'])*(1+Decimal(a['receipts'])/100) if inflow else 1+Decimal(a['costs'])/100
            due=original+timedelta(days=a['delay'] if inflow else 0)
            if original<start:overdue+=1;continue
            if due>=end:beyond+=1;continue
            buckets[(due-start).days//7][0 if inflow else 1]+=amount
        cash=Decimal(a['opening']);buffer=Decimal(a['buffer']);maximum=Decimal(0);first=None
        for week,(incoming,outgoing) in enumerate(buckets,1):
            opening=cash;cash+=incoming-outgoing;gap=max(Decimal(0),buffer-cash)
            maximum=max(maximum,gap)
            if gap and first is None:first=week
            actual={'opening':money(opening),'inflows':money(incoming),'outflows':money(outgoing),'closing':money(cash),'headroom':money(cash-buffer),'shortfall':money(gap)}
            for key,value in actual.items():
                assert value==expected[name]['points'][week-1][key],(name,week,key,value)
                checks+=1
        assert (money(cash),money(maximum),first,overdue,beyond)==(expected[name]['ending'],expected[name]['maximumShortfall'],expected[name]['firstBreach'],expected[name]['overdue'],expected[name]['beyond'])
        checks+=5
(here/'independent-arithmetic-evidence.json').write_text(json.dumps({'kind':'FICTIONAL_TEST_EVIDENCE','scenarios':7,'checks':checks,'failures':[]},indent=2)+'\n',encoding='utf-8')
print(f'{checks} independent decimal checks passed')
